
package edu.espoch.m.derivadalogreact;

import ec.edu.espoch.interfaz.Interfaz;

public class DerivadaLogReact {

    public static void main(String[] args) {
        Interfaz interfaz = new Interfaz();
        interfaz.setVisible(true);
        interfaz.setLocationRelativeTo(null);
    }
}
