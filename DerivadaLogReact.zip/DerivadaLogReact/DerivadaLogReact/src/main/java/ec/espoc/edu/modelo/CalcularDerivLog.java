/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.espoc.edu.modelo;

import ec.edu.espoch.interfaz.Interfaz;
import io.reactivex.Observable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CalcularDerivLog {
    private Interfaz vista;
    public Observable<String> resolverConBaseObservable(String valorIngresado) {
        return Observable.just(valorIngresado)
                .map(this::resolverConBase);
    }

    public CalcularDerivLog(Interfaz vista) {
        this.vista = vista;
    }

    public Observable<String> resolverNaturalesObservable(String valorIngresado) {
        return Observable.just(valorIngresado)
                .map(this::resolverNaturales);
    }

    public String resolverConBase(String valorIngresado) {
       
        String patternString = "\\(([^)]+)\\)";
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(valorIngresado);
        String contenidoParentesis = "";
        if (matcher.find()) {
            contenidoParentesis = matcher.group(1);
        }
        

        String paternString = "log(10|[0-9]+)";
        Pattern patern = Pattern.compile(paternString);
        Matcher macher = patern.matcher(valorIngresado);
        String numeroDespuesDeLog;
        if (macher.find()) {
            numeroDespuesDeLog = macher.group(1);      
        }else{
            numeroDespuesDeLog = "10";
        }
        
        String[] vSeparados = contenidoParentesis.split(" ");
        
        String resultado = "";


        boolean agregadoPrimerTermino = false;

        for (String termino : vSeparados) {
            int coeficiente;
            int exponente;

            boolean tieneX;

            if (termino.contains("x")) {
                tieneX = true;

                String c = termino.substring(0, termino.indexOf("x"));

                if (c.isEmpty() || c.equals("+")) {
                    coeficiente = 1;
                } else if (c.equals("-")) {
                    coeficiente = -1;
                } else {
                    coeficiente = Integer.parseInt(c);
                }

                if (termino.contains("^")) {
                    String e = termino.substring(termino.indexOf("^") + 1);

                    exponente = Integer.parseInt(e);
                } else {
                    exponente = 1;
                }
            } else {
                tieneX = false;
                coeficiente = Integer.parseInt(termino);
                exponente = 0;
            }

            String resultadoParcial;

            if (tieneX & exponente != 1 & exponente != 2) {
                int nuevoExponente = exponente - 1;

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                String nuevoExponenteString = String.valueOf(nuevoExponente);

                resultadoParcial = nuevoCoeficienteString + "x^" + nuevoExponenteString;
            } else if (tieneX & exponente == 2) {

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                resultadoParcial = nuevoCoeficienteString + "x";
            } else if (tieneX & exponente == 1) {
                String nuevoCoeficienteString = String.valueOf(coeficiente);
                resultadoParcial = nuevoCoeficienteString;
            } else {
                resultadoParcial = "";
            }

            if (!agregadoPrimerTermino) {
                resultado = resultado + resultadoParcial;
                agregadoPrimerTermino = true;
            } else {
                if (coeficiente > 0) {
                    resultado = resultado + "  +" + resultadoParcial;
                } else {
                    resultado = resultado + "  " + resultadoParcial;
                }
            }
        } 
        return "(" + resultado + ")/(" + "(" + contenidoParentesis + ")" + "ln" + numeroDespuesDeLog + ")";
    }

    public String resolverNaturales(String valorIngresado) {
        String nV = valorIngresado.replace("ln", "");
        String nVal = nV.replace("(", "");
        String nValor = nVal.replace(")", "");
        
        String[] vSeparados = nValor.split(" ");
        
        String resultado = "";
      

        boolean agregadoPrimerTermino = false;

        for (String termino : vSeparados) {
            int coeficiente;
            int exponente;

            boolean tieneX;

            if (termino.contains("x")) {
                tieneX = true;

                String c = termino.substring(0, termino.indexOf("x"));

                if (c.isEmpty() || c.equals("+")) {
                    coeficiente = 1;
                } else if (c.equals("-")) {
                    coeficiente = -1;
                } else {
                    coeficiente = Integer.parseInt(c);
                }

                if (termino.contains("^")) {
                    String e = termino.substring(termino.indexOf("^") + 1);

                    exponente = Integer.parseInt(e);
                } else {
                    exponente = 1;
                }
            } else {
                tieneX = false;

                coeficiente = Integer.parseInt(termino);

                exponente = 0;
            }

            String resultadoParcial;

            if (tieneX & exponente!=1 & exponente!=2) {
                int nuevoExponente = exponente - 1;

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                String nuevoExponenteString = String.valueOf(nuevoExponente);

                resultadoParcial = nuevoCoeficienteString + "x^" + nuevoExponenteString;
            } else if(tieneX & exponente==2){

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                resultadoParcial = nuevoCoeficienteString + "x";
            } else if(tieneX & exponente==1){
                String nuevoCoeficienteString = String.valueOf(coeficiente);
                resultadoParcial = nuevoCoeficienteString;
            }else{
                resultadoParcial = "";
            }

            if (!agregadoPrimerTermino) {
                resultado = resultado + resultadoParcial;
                agregadoPrimerTermino = true;
            } else {
                if (coeficiente > 0) {
                    resultado = resultado + "  +" + resultadoParcial;
                } else {
                    resultado = resultado + "  " + resultadoParcial;
                }
            }
        }
        return "(" + resultado + ")/(" + nValor + ")";    
    }
    
}

