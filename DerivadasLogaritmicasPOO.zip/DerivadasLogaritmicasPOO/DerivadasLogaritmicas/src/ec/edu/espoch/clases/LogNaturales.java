package ec.edu.espoch.clases;

public class LogNaturales {
    
    public String resolver(String valorIngresado){
        
        String nV = valorIngresado.replace("ln", "");
        String nVal = nV.replace("(", "");
        String nValor = nVal.replace(")", "");
        
        String[] vSeparados = nValor.split(" ");
        
        String resultado = "";
      

        boolean agregadoPrimerTermino = false;

        for (String termino : vSeparados) {
            int coeficiente;
            int exponente;

            boolean tieneX;

            if (termino.contains("x")) {
                tieneX = true;

                String c = termino.substring(0, termino.indexOf("x"));

                if (c.isEmpty() || c.equals("+")) {
                    coeficiente = 1;
                } else if (c.equals("-")) {
                    coeficiente = -1;
                } else {
                    coeficiente = Integer.parseInt(c);
                }

                if (termino.contains("^")) {
                    String e = termino.substring(termino.indexOf("^") + 1);

                    exponente = Integer.parseInt(e);
                } else {
                    exponente = 1;
                }
            } else {
                tieneX = false;

                coeficiente = Integer.parseInt(termino);

                exponente = 0;
            }

            String resultadoParcial;

            if (tieneX & exponente!=1 & exponente!=2) {
                int nuevoExponente = exponente - 1;

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                String nuevoExponenteString = String.valueOf(nuevoExponente);

                resultadoParcial = nuevoCoeficienteString + "x^" + nuevoExponenteString;
            } else if(tieneX & exponente==2){

                int nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                resultadoParcial = nuevoCoeficienteString + "x";
            } else if(tieneX & exponente==1){
                String nuevoCoeficienteString = String.valueOf(coeficiente);
                resultadoParcial = nuevoCoeficienteString;
            }else{
                resultadoParcial = "";
            }

            if (!agregadoPrimerTermino) {
                resultado = resultado + resultadoParcial;
                agregadoPrimerTermino = true;
            } else {
                if (coeficiente > 0) {
                    resultado = resultado + "  +" + resultadoParcial;
                } else {
                    resultado = resultado + "  " + resultadoParcial;
                }
            }
        }
        return "(" + resultado + ")/(" + nValor + ")";    
    }
}
