package ec.edu.espoch.main;

import ec.edu.espoch.vista.Interfaz;

public class DerivadaLog {
    public static void main(String[] args){
        Interfaz inter = new Interfaz();
        inter.setVisible(true);
        inter.setLocationRelativeTo(null);
    }
}
