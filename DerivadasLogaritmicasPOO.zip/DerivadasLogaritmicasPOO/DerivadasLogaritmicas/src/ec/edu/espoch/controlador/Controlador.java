/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espoch.controlador;

import ec.edu.espoch.clases.LogConBase;
import ec.edu.espoch.clases.LogNaturales;
import ec.edu.espoch.vista.Interfaz;


public class Controlador {
    private Interfaz vista;
    private LogConBase logConBaseModel;
    private LogNaturales logNaturalesModel;

    public Controlador(Interfaz vista) {
        this.vista = vista;
        this.logConBaseModel = new LogConBase();
        this.logNaturalesModel = new LogNaturales();
    }

    public void resolverDerivada() {
        String valorIngresado = vista.getEntrada();
        String tipoDerivada = vista.getTipoDerivada();
        String resultado = "";

        if ("Naturales".equals(tipoDerivada)) {
            resultado = logNaturalesModel.resolver(valorIngresado);
        } else if ("Con base".equals(tipoDerivada)) {
            resultado = logConBaseModel.resolver(valorIngresado);
        }

        vista.mostrarResultado(resultado);
    }
}
